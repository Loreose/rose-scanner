fx_version 'cerulean'
game 'gta5'

author 'Loreose'
description 'ROSE Model Scanner'
version '1.0.0'

client_scripts {
    'config.lua',
    'client.lua',
}

server_scripts {
    'config.lua',
    'server.lua',
}

shared_scripts {
    '@ox_lib/init.lua'
}